import React from 'react';
import './CategoryCard.css'

function CategoryCard(props) {
    return (
        <div className='category-card'>
            
        </div>
    );
}

export default CategoryCard;