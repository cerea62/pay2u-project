import React from 'react';
import { Link } from 'react-router-dom';
import './ServicesCard.css';
import ButtonNavigation from '../ButtonNavigation/ButtonNavigation';

function ServicesCard({path, image, title, description, isActive}) {
    return (
        <>
            <li>
                <Link to={path} className='services-card'>
                    <img className='services-card__image' alt={title} src={image} />
                    <div className='services-card__content'>
                        <div className='services-card__heading'>
                        <h3 className='services-card__title'>{title}</h3>
                        {isActive ? (                        
                        <div className='services-card__marker'></div>
                        ):(null)
                        }

                        </div>
                 

                        <p className='services-card__description'>{description}</p>
                    </div>
                    <ButtonNavigation />
                </Link>
            </li>

        </>

    );
}

export default ServicesCard;