import React from 'react';
import { createContext } from 'react';

export  const CurrentUserContext = createContext();