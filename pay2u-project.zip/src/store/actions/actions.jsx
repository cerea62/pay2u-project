import { EDIT_IS_SIGNED } from "../../utils/constants";

export const editIsSigned = {
    type: EDIT_IS_SIGNED,
    playload: {
        isSigned: false,
    }
}