import image1 from '../images/categories/Alert.jpg'
import image2 from '../images/categories/Alert-1.jpg'
import image3 from '../images/categories/Alert-2.jpg'
import image4 from '../images/categories/Alert-3.jpg'
import image5 from '../images/categories/Alert-4.jpg'
import image6 from '../images/categories/Alert-5.jpg'

const card1 = {image: image1, id: 1};
const card2 = {image: image2, id: 2};
const card3 = {image: image3, id: 3};
const card4 = {image: image4, id: 4};
const card5 = {image: image5, id: 5};
const card6 = {image: image6, id: 6};

const categories = [card1, card2, card3, card4, card5, card6];

export default categories;