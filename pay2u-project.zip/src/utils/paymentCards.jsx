import image1 from '../images/services-icons/yandex-music.svg'

const paymentCards = [
    {
        id: 1,
        icon: image1,
        title: 'Яндекс Музыка',
        dateOfDebiting: '20.03.2024',
        cashback: '50',
        cost: '100',
        paided: true,
    },
    {
        id: 2,
        icon: image1,
        title: 'Яндекс Музыка',
        dateOfDebiting: '20.03.2024',
        cashback: '50',
        cost: '100',
        paided: true,
    },
    {
        id: 3,
        icon: image1,
        title: 'Яндекс Музыка',
        dateOfDebiting: '20.03.2024',
        cashback: '50',
        cost: '100',
        paided: false,
    },
]
export default paymentCards;