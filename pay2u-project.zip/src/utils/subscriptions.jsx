import logo1 from '../images/services-icons/yandex-music.svg'
import logo2 from '../images/services-icons/okko.svg'

const subscriptions = [
    {
        id: 1,
        logo: logo1,
        cost: 100,
        period: 'месяц',
        title: 'Яндекс Музыка на месяц',
        duration: '20 апреля',
    },
    {
        id: 2,
        logo: logo2,
        cost: 1500,
        period: 'год',
        title: 'Okko - домашний кинотеатр',
        duration: '15 апреля',
    },
    {
        id: 3,
        logo: logo1,
        cost: 100,
        period: 'месяц',
        title: 'Яндекс Музыка на месяц',
        duration: '20 апреля',
    },
    {
        id: 4,
        logo: logo1,
        cost: 100,
        period: 'месяц',
        title: 'Яндекс Музыка на месяц',
        duration: '20 апреля',
    },
    {
        id: 5,
        logo: logo1,
        cost: 100,
        period: 'месяц',
        title: 'Яндекс Музыка на месяц',
        duration: '20 апреля',
    },

]
export default subscriptions;